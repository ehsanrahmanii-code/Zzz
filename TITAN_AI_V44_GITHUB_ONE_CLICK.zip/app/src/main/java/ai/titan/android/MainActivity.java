package ai.titan.android;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;

public class MainActivity extends Activity {
    private static final String URL = "http://127.0.0.1:8080/";
    private final Handler handler = new Handler(Looper.getMainLooper());
    private WebView webView;
    private TextView status;
    private boolean started = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        checkStorageAndStart();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF050812);

        status = new TextView(this);
        status.setText("TITAN AI\nدر حال آماده‌سازی موتور...");
        status.setTextColor(0xFFEAF2FF);
        status.setTextSize(16);
        status.setGravity(android.view.Gravity.CENTER_HORIZONTAL);
        status.setPadding(32, 48, 32, 32);
        root.addView(status, new LinearLayout.LayoutParams(-1, -2));

        webView = new WebView(this);
        webView.setBackgroundColor(0xFF050812);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return false;
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setDatabaseEnabled(true);
        webView.getSettings().setAllowFileAccess(false);
        webView.getSettings().setAllowContentAccess(false);
        webView.getSettings().setBuiltInZoomControls(false);
        webView.getSettings().setDisplayZoomControls(false);
        webView.getSettings().setLoadWithOverviewMode(false);
        webView.getSettings().setUseWideViewPort(false);

        root.addView(webView, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);
    }

    private void checkStorageAndStart() {
        if (android.os.Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) {
            status.setText("TITAN AI\nبرای استفاده از مسیر ذخیره‌سازی اختصاصی TITAN، دسترسی فایل‌ها لازم است.\n\nصفحه مجوز Android باز می‌شود.");
            try {
                Intent intent = new Intent(
                    Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:" + getPackageName())
                );
                startActivity(intent);
            } catch (Throwable e) {
                startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
            }
            return;
        }
        startTitan();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!started) {
            handler.postDelayed(this::checkStorageAndStart, 250);
        }
    }

    private void startTitan() {
        if (started) return;
        started = true;
        status.setText("TITAN AI\nموتور Python و داشبورد در حال راه‌اندازی...");
        try {
            Python py = Python.getInstance();
            PyObject module = py.getModule("android_entry");
            module.callAttr("start");
            waitForServer();
        } catch (Exception e) {
            started = false;
            status.setText("TITAN AI\nخطا در راه‌اندازی موتور:\n" + e.getMessage());
        }
    }

    private void waitForServer() {
        handler.postDelayed(new Runnable() {
            int tries = 0;
            @Override public void run() {
                if (isFinishing()) return;
                if (tries++ > 120) {
                    status.setText("TITAN AI\nسرور داخلی در زمان مورد انتظار آماده نشد.\nلطفاً برنامه را دوباره باز کنید.");
                    return;
                }
                try {
                    Python py = Python.getInstance();
                    boolean ready = py.getModule("android_entry")
                            .callAttr("is_server_ready")
                            .toBoolean();
                    if (ready) {
                        status.setVisibility(View.GONE);
                        webView.setVisibility(View.VISIBLE);
                        webView.loadUrl(URL);
                        return;
                    }
                } catch (Exception ignored) {}
                handler.postDelayed(this, 500);
            }
        }, 300);
    }

    @Override
    protected void onDestroy() {
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
