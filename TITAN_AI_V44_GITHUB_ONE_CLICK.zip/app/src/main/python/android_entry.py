"""Android bootstrap for the unmodified TITAN V44 Flask engine."""
import threading
import time

_started = False
_lock = threading.Lock()

def start():
    global _started
    with _lock:
        if _started:
            return
        _started = True

    import titan_engine

    def runner():
        # Keep the Flask server off the Android UI thread.
        titan_engine.run_titan(open_browser=False)

    threading.Thread(target=runner, name="titan-android-runtime", daemon=True).start()

def is_server_ready(host="127.0.0.1", port=8080):
    import socket
    try:
        with socket.create_connection((host, int(port)), timeout=0.35):
            return True
    except OSError:
        return False
