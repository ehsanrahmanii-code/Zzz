# TITAN AI V44 — Android 14 / Xiaomi Note 12S

This repository packages the supplied `TITAN_V44_BALANCED_LEARNING_FINAL.py` as an Android APK.

## Architecture

- Python engine: Chaquopy 17.0 / Python 3.13
- Android: Gradle + Android Gradle Plugin 9.2.0
- UI: the original Flask dashboard rendered locally in Android WebView
- Network: the Python engine uses the phone's Internet connection for live market/API data
- CPU ABI: `arm64-v8a` (optimized for modern Xiaomi phones)
- Local server: `127.0.0.1:8080`
- Persistent TITAN root: `/storage/emulated/0/TAITAN`

The supplied Python engine is copied as `app/src/main/python/titan_engine.py` without changing its analysis code.

## Android 14 storage

The engine intentionally uses `/storage/emulated/0/TAITAN`. Android 11+ requires the user to grant "Allow access to manage all files" for this exact storage model. On first launch, TITAN opens the Android permission screen. Grant it, return to TITAN, and the engine starts.

## Build

```bash
gradle :app:assembleDebug
```

The APK is:

`app/build/outputs/apk/debug/app-debug.apk`

## GitHub Actions

Push the repository to GitHub, then run:

Actions -> Build TITAN AI APK -> Run workflow

The finished APK is uploaded as the `TITAN_AI_V44_ANDROID` workflow artifact.

## Important

This app is analysis-only. It does not execute trades or place orders.
