# TITAN AI — One-click APK build

1. Upload/push this project to a GitHub repository.
2. Open **Actions**.
3. Select **Build TITAN AI APK**.
4. Click **Run workflow**.
5. When it finishes, open the run and download the artifact **TITAN-AI-APK**.

The workflow builds the debug APK with Gradle and publishes it as a GitHub Actions artifact.
